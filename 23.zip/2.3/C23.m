clear; clc; close all;
%% 1
N = 128;
S = zeros(1, N);
S(8) = 2;
S(24) = 2;
S(40) = 3;
Signal = ifft(S, N);
figure
plot(linspace(0, 1, N), abs(Signal))
xlabel('Time')
ylabel('Amp')
title('Signal')
%% 2
SNR = 25;
NoisedSignal = NoiseGenerator(SNR, Signal);
figure
plot(linspace(0, 1, N), abs(NoisedSignal))
xlabel('Time')
ylabel('Amp')
title('NoisedSignal')
%% 3
Noise = NoisedSignal - Signal;
P_Signal = PowerSignal(Signal);
P_Noise = PowerSignal(Noise);
P_NoisedSignal = PowerSignal(NoisedSignal);
%% 4
SignalSpec = fft(Signal, N);
NoiseSpec = fft(Noise, N);
NoisedSignalSpec = fft(NoisedSignal, N);
P_SignalSpec = PowerSignal(SignalSpec)/N;
P_NoiseSpec = PowerSignal(NoiseSpec)/N;
P_NoisedSignalSpec = PowerSignal(NoisedSignalSpec)/N;
if ((P_SignalSpec/P_Signal >= (1 - 0.001)) && (P_NoisedSignalSpec/P_NoisedSignal >= (1 - 0.001)) && (P_NoiseSpec/P_Noise >= (1 - 0.001)))
    disp('True')
else
    disp('False')
end
%% 5
FilteredNoisedSignal = FilterSignal(NoisedSignal);
figure
plot(linspace(0, 1, N), abs(FilteredNoisedSignal))
xlabel('Time')
ylabel('Amp')
title('FilteredNoisedSignal')
%% 6
SNR_NoisedSignal = 20 * log10(rms(Signal)/rms(NoisedSignal - Signal));
SNR_FilteredNoisedSignal = 20 * log10(rms(Signal)/rms(FilteredNoisedSignal - Signal));
fprintf('SNR_NoisedSignal = %f\n', SNR_NoisedSignal);
fprintf('SNR_FilteredNoisedSignal = %f\n', SNR_FilteredNoisedSignal);
disp('FilteredNoisedSignal is better than NoisedSignal because it has bigger SNR.');