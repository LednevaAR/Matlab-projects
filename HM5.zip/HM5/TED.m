function result = TED(Signal, Fs, symbol_rate)
    Sig = Signal(1 : length(Signal) / (2 * symbol_rate) : end);
    k = 1;
    for m = 2 : length(Sig) / 2
        ted_output(k) = abs(Sig(2 * m - 2) * (sign(Sig(2 * (m - 1) - 1)) - sign(Sig(2 * m - 1))));
        k = k + 1;
    end
    result = ted_output;
end