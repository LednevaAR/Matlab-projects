clear; clc; close all;
%%
LH = 2^11 - 1;
%%
coeff = 4005;
m_seq = RSLOS(LH, coeff);
disp(sum(m_seq)) % число единиц
disp(abs(sum(m_seq - 1))) % число нулей
AutoCorrm = AutoCorr(m_seq);
BN = linspace(1, numel(AutoCorrm), numel(AutoCorrm));
f = figure();
plot(BN, AutoCorrm);
xlabel('Bit number');
ylabel('AutoCorrelation function');
title('AutoCorrelation function of m-seq');
saveas(f, 'ACF_m_seq.fig')
%%
Fs = 1000;
symbol_rate = 1000;
e = 0.4;
%%
SNR = 20;
STO = 0.01;
Signal = mapping(m_seq, "QPSK");
Signal1 = ifft(fft(Signal) .* exp(-1j * 2 * pi * STO * Fs * (0 : length(fft(Signal)) - 1) / length(fft(Signal))));
Signal1 = awgn(Signal1, SNR, 'measured');
ted_output1 = TED(Signal1, Fs, symbol_rate);
%h(1) = - (1 / 6) * (e - 1) * (e - 2) * (e - 3);
%h(2) = - (1 / 2) * e * (e - 2) * (e - 3);
%h(3) = - (1 / 2) * e * (e - 1) * (e - 3);
%h(4) = - (1 / 6) * e * (e - 1) * (e - 2);
h(1) = 1 - e;
h(2) = e;
Signal2 = conv(Signal1, h, 'same');
f = figure;
scatter(real(Signal1), imag(Signal1));
f = figure;
scatter(real(Signal2), imag(Signal2));
%%
SNR = 20;
SCO = 1;
Signal = mapping(m_seq, "QPSK");
Signal1 = circshift(Signal, [0, SCO]);
Signal1 = awgn(Signal1, SNR, 'measured');
ted_output2 = TED(Signal1, Fs, symbol_rate);
%h(1) = - (1 / 6) * (e - 1) * (e - 2) * (e - 3);
%h(2) = - (1 / 2) * e * (e - 2) * (e - 3);
%h(3) = - (1 / 2) * e * (e - 1) * (e - 3);
%h(4) = - (1 / 6) * e * (e - 1) * (e - 2);
h(1) = 1 - e;
h(2) = e;
Signal2 = conv(Signal1, h, 'same');
f = figure;
scatter(real(Signal1), imag(Signal1));
f = figure;
scatter(real(Signal2), imag(Signal2));
scatter(real(rxSync), imag(rxSync))

