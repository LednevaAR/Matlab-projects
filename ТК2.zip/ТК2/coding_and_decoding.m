clear; clc; close all;
%%
fileID = fopen('2.txt','r');
message = fscanf(fileID, '%s');
message = message(1 : ceil(strlength(message)));
%% coding
%message = 'на_дворе_трава_на_траве_дрова_на_дворе_трава_на_траве_дрова';
%message = 'abacabadabacabae';
%message = 'ababababab';
%message = 'aaaaaaaaaaaaaaaaaaaaaa';
%message = 'abcabcabc';
%message = 'abbaaaa';
dict = dictionary;
u = unique(message);
binmessage = "";
n = 0;
max = 13;
result = [];
binresult = "";
for j = 1 : length(u)
    dict(u(j)) = j - 1; % double(u(j));
end
code = j;
if (~isempty(message))
    input = message(1);
    if (length(message) == 1)
        result = [result dict(input)];
    end
    i = 1;
    while (i < length(message))
        i = i + 1;
        if (isKey(dict, strcat(input, message(i))))
            input = strcat(input, message(i));
        else
            result = [result dict(input)];
            dict(strcat(input, message(i))) = code;
            code = code + 1;
            input = message(i);
        end
        if (length(dict) >= 2 ^ 12 - 1)
            dict = dictionary;
            n = 1;
            for j = 1 : length(u)
                dict(u(j)) = j - 1; % double(u(j));
                code = j;
            end
        end
    end
    if (length(message) == i)
        result = [result dict(input)];
    end
end
%disp(message)
%disp(dict)
%disp(result)
for k = 1 : length(message)
    binmessage = strcat(binmessage, string(dec2bin(double(message(k)))));
end
binresult1 = string(dec2bin(result, (1 - n) * ceil(log2(code)) + n * max));
binresult = strcat(binresult, dec2bin((1 - n) * ceil(log2(code)) + n * max, ceil(log2(max))));
for k = 1 : length(binresult1)
    binresult = strcat(binresult, binresult1(k));
end
disp(strlength(binmessage))
disp(strlength(binresult))
disp(strlength(binmessage) / strlength(binresult))
disp(length(keys(dict)) - 1)
%% decoding
decdict = dictionary;
decresult = "";
newresult = [];
binresult = char(binresult);
len = bin2dec(binresult(1 : ceil(log2(max))));
binresult = binresult(ceil(log2(max)) + 1 : end);
for i = 1 : len : length(binresult)
    newresult = [newresult bin2dec(binresult(i : i + len - 1))];
end
for j = 1 : length(u)
    decdict(string(j - 1)) = u(j); % double(u(j));
end
code = j;
if (~isempty(newresult))
    if (length(newresult) == 1)
        decresult = strcat(decresult, decdict(newresult(1)));
    end
    decresult = strcat(decresult, decdict(newresult(1)));
    input = decresult;
    i = 2;
    k = 1;
    while (i < length(newresult))
        d = char(decresult);
        if (isKey(decdict, newresult(i)))
            decresult = strcat(decresult, decdict(newresult(i)));
            i = i + 1;
        else
            k = k + 1;
            if (length(d) < k)
                decdict(code) = strcat(input, input(1));
                code = code + 1;
            else
                if (sum(values(decdict) == strcat(input, d(k))) > 0)
                    input = strcat(input, d(k));
                else
                    decdict(code) = strcat(input, d(k));
                    code = code + 1;
                    input = d(k);
                end
            end
        end
        if (length(decdict) >= 2 ^ max - 1)
            decdict = dictionary;
            for j = 1 : length(u)
                decdict(string(j - 1)) = u(j); % double(u(j));
                code = j;
            end
        end
    end
    if (length(newresult) == i)
        decresult = strcat(decresult, string(decdict(newresult(i))));
    end
    d = char(decresult);
    while (k < strlength(decresult))
        k = k + 1;
        if (sum(values(decdict) == strcat(input, d(k))) > 0)
            input = strcat(input, d(k));
        else
            decdict(code) = strcat(input, d(k));
            code = code + 1;
            input = d(k);
        end
    end
end
%disp(decdict)
%disp(decresult)
%построить зависимость от сжатия (до 2^14) от длины словаря
%ограничение по битам (кодирование и декодирование)