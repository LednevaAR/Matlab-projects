clc; % чистка командного окна
close all; % закрыть дополнительные окна 
clear all; % очистить память
rng(1); % фиксирование начального состояния генератора случайных чисел Матлаба

%% 
% Конфигурация модели
% выбор созвездия
SNR = randi(101) - 1;
%SNR = zeros(1, 31);
%for j = 1 : 31
%SNR(j) = 3 * j - 1;
Register = [1 0 0 1 0 1 0 1 0 0 0 0 0 0 0];
constellation = "16-QAM"; % "BPSK"; % "QPSK"
File = 'HM1.jpg'; % Адрес файла
[Dictionary, D, ~] = constellation_func(constellation); % to-do lab 1
QAM_cells = length(Dictionary); % количество точек созвездия
N_carrier = 400;
N_fft = 1024;
T_guard = N_fft / 8;
Amount_OFDM_Frames = 60;
Amount_OFDM_Symbols_per_Frame = 5;
Time_Delay = randi(N_fft + T_guard + 1) - 1;
%Freq_Shift = (randi(61) - 31);
Freq_Shift = 0.01;
Channel = [0, 1; 4, 0.6; 10, 0.3];
%%
%Передатчик
Input_Bit_Buffer = file_reader(File);
%disp(sum(Input_Bit_Buffer > 255))
Input_Bit_Buffer_Rand = randomizer(Input_Bit_Buffer, Register, Amount_OFDM_Frames);
Tx_IQ_points = mapping(Input_Bit_Buffer_Rand, constellation);
Tx_OFDM_symbols = OFDM_Mod(Tx_IQ_points, N_fft, N_carrier, T_guard);
Tx_OFDM_Signal = signal_generator(Tx_OFDM_symbols);
%%
%PAPR = 10 * log10(max(abs(Tx_OFDM_Signal) .^ 2) / mean(abs(Tx_OFDM_Signal) .^ 2));
%PAPR_slid_wind = compute_PAPR_slid_wind(Tx_OFDM_Signal, N_fft);
%[CCDF, PAPR_sorted] = compute_CCDF(PAPR_slid_wind);
%semilogy(PAPR_sorted, CCDF);
%%
%канал Lab 4-5 
% noiseData = Noise (Tx_OFDM_Signal, SNR); %lab 4 | добавление абгш
% freq_shifted_data = frequense_shift(noiseData, Freq_shift, N_fft,T_guard); % lab 4 | частотный сдвиг
% multi_data = multipath(freq_shifted_data,channel); % lab 4 | многолучевой прием
% time_shifted_data = delay(multi_data,Time_delay); % lab 4
Rx_OFDM_Signal = Tx_OFDM_Signal;
% Гауссовский шум
Rx_OFDM_Signal = NoiseGenerator(SNR, Rx_OFDM_Signal);
% Частотная рассинхронизация
Rx_OFDM_Signal = Rx_OFDM_Signal .* exp(1j * 2 * (1 : size(Rx_OFDM_Signal, 2)) * pi * Freq_Shift  / N_fft);
% Многолучевое распространение
Rx_OFDM_Signal = multipath(Rx_OFDM_Signal, Channel);
% Временная рассинхронизация
Rx_OFDM_Signal = [Rx_OFDM_Signal(1, Time_Delay + 1 : end), zeros(1, Time_Delay)];
%%
%приемник
%Rx_OFDM_Signal = [Rx_OFDM_Signal(1 + T_guard : end), zeros(1, T_guard)]; %T_guard / 2, T_guard
Rx_OFDM_data = OFDM_Signal_Demod(Rx_OFDM_Signal, T_guard, N_fft);
for i = 1 : size(Rx_OFDM_data, 1)
    Rx_IQ(i, 1 : N_fft) = fft(Rx_OFDM_data(i, 1 : end), N_fft);
end
Rx_IQ_points = conj(reshape(Rx_IQ(:, 1 : N_carrier)', 1, numel(Rx_IQ(:, 1 : N_carrier))));
MER = MER_my_func(Rx_IQ_points, constellation);
Output_Bit_Buffer = demapping(Rx_IQ_points, constellation);
Output_Bit_Buffer_Derand = randomizer(Output_Bit_Buffer, Register, Amount_OFDM_Frames);
Probability = Error_check(Input_Bit_Buffer, Output_Bit_Buffer_Derand);
%BER(j) = Error_check(Input_Bit_Buffer, Output_Bit_Buffer_Derand);
%end
%%
%f = figure();
% plot(SNR, BER)
% title("BER(SNR)")
% xlabel("SNR, dB")
% ylabel("BER")
% grid on
%saveas(f, "BER_SNR.fig")
%%
f = figure();
plot(1 : size(Rx_IQ, 2), abs(Rx_IQ(2, 1 : end)))
xlim([0 1024])
title("Plot")
xlabel("Frequency")
ylabel("Amplitude")
grid on
saveas(f, "АЧХ.fig")
f = figure();
s = scatter(real(Rx_IQ_points), imag(Rx_IQ_points), "filled");
s.SizeData = 1;
title("Plot")
xlabel("In-Phase")
ylabel("Quadrature")
xlim([-2 2])
ylim([-2 2])
[Dictionary, Bit_depth_Dict] = constellation_func(constellation);
Dict = name(constellation);
for i = 1:length(Dictionary)
    text(real(Dictionary(i)), imag(Dictionary(i)), '\leftarrow' + Dict(i));
end
grid on
saveas(f, "Const.fig")
%%
Output_Buffer = num2str(reshape(Output_Bit_Buffer_Derand, numel(Output_Bit_Buffer_Derand) / 8, 8));
for i = 1 : size(Output_Buffer, 1)
    Output(i, 1 : 8) = regexprep(Output_Buffer(i, 1 : end), ' ', '');
end
Output = bin2dec(Output);
Output = Output';
Out = uint8(reshape(Output, 100, 200, 3));
imwrite(Out, 'image.jpg','jpg');