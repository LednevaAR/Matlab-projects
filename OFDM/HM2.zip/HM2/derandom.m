function derand = derandom(Output_Bit_Buffer, Register, Amount_OFDM_Frames)
    derand = zeros(1, numel(Output_Bit_Buffer));
    for i = 1 : numel(Output_Bit_Buffer)
        if mod(i, numel(Output_Bit_Buffer) / Amount_OFDM_Frames) == 1
            Reg = Register;
        end
        Reg = circshift(Reg, 1);
        Reg(1) = xor(Reg(1), Reg(numel(Reg)));
        derand(i) = xor(Reg(1), Output_Bit_Buffer(i));
    end
end