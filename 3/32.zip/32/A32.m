clear; clc; close all;
%%
Fs = 2500;
T = 3;
A = 3;
f = 1000;
Time = linspace(0, T, T * Fs);
audio = A * sin(Time * 2 * pi * f);
figure
plot(Time, audio)
xlabel('Time')
ylabel('Amp')
title('Signal')
ylim([-A A])
n = length(audio);
fr = (-n/2:n/2-1)*(Fs/n);
figure
plot(fr,  abs(fft(audio)))
xlabel('Frequency')
ylabel('Amp')
title('Spec')
audiowrite('task2.wav', audio/A, Fs)
%%
C = 2;
audio(audio > C) = C;
audio(audio < -C) = -C;
figure
plot(Time, audio)
xlabel('Time')
ylabel('Amp')
title('ClippedSignal')
ylim([-A A])
n = length(audio);
fr = (-n/2:n/2-1)*(Fs/n);
figure
plot(fr, abs(fft(audio)))
xlabel('Frequency')
ylabel('Amp')
title('ClippedSpec')
audiowrite('task2new.wav', audio/A, Fs)
fprintf("Изменился спектр сигнала: стало больше гармоник (см. графики), то есть ширина спектра стала больше.\nУ самого сигнала действительно отсеклось все, где амплитуда больше 2, в остальном он остался прежним.\n")
disp('Амплитуда сигнала стала 2, частота осталась прежней.')