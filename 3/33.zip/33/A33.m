clear; clc; close all;
%%
[audio, Fs] = audioread("task3.wav");
fprintf('Исходная частота дискретизации равна %d\n', Fs)
figure;
Time = linspace(0, length(audio) ./ Fs, length(audio));
plot(Time, audio);
xlabel('Time')
ylabel('Amp')
title('Signal')
n = length(audio);
f = (-n/2:n/2-1)*(Fs/n);
Spec = fft(audio);
figure;
plot(f, abs(Spec));
xlabel('Frequency')
ylabel('Amp')
title('Spec')
%%
Fs = Fs/2;
audio1 = zeros(round(size(audio, 1)/2), size(audio, 2));
for i = 1:length(audio1)
    audio1(i, :) = audio(2 * i - 1, :);
end
audiowrite("1.wav", audio1, Fs);
figure;
Time = linspace(0, length(audio1) ./ Fs, length(audio1));
plot(Time, audio1);
xlabel('Time')
ylabel('Amp')
title('Signal for Fs/2')
n = length(audio1);
f = (-n/2:n/2-1)*(Fs/n);
Spec = fft(audio1);
figure;
plot(f, abs(Spec));
xlabel('Frequency')
ylabel('Amp')
title('Spec for Fs/2')
disp('При уменьшении частоты дискретизации спектр сигнала стаовится более узким, а его качество хуже.')
%%
Fs = 2 * Fs;
audio2 = zeros(size(audio, 1), size(audio, 2));
for i = 1:length(audio2)
    if mod(i, 2) == 0
        audio2(i, :) = (audio1(round(i/2), :) + audio1(round(i/2) + 1, :))/2;
    else
        audio2(i, :) = audio1(round(i/2),:);
    end
end
audiowrite("2.wav", audio2, Fs);
figure;
Time = linspace(0, length(audio2) ./ Fs, length(audio2));
plot(Time, audio2);
xlabel('Time')
ylabel('Amp')
title('Restored signal for Fs')
n = length(audio2);
f = (-n/2:n/2-1)*(Fs/n);
Spec = fft(audio2);
figure;
plot(f, abs(Spec));
xlabel('Frequency')
ylabel('Amp')
title('Restored spec for Fs')